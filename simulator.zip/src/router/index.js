import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../components/Home";
import Simulator from "../components/Simulator";
import About from "../components/About";
Vue.use(VueRouter);
const routes = [
  { path: "/home", component: Home, name: "Home" },
  { path: "/Simulator", component: Simulator, name: "Simulator" },
  { path: "/about", component: About }
];

const router = new VueRouter({
  mode: "history",
  routes
});

export default router;
