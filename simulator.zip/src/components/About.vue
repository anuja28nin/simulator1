<template>
  <div>About Us Page</div>
</template>
<script>
export default {
  name: "About",
};
</script>