<template>
  <div>
    <h1>Welcome to the EFM Simulator</h1>
    <form>
      <fieldset>
        <legend>Login</legend>
        <h3>
          <label for="email">&nbsp; &nbsp; &nbsp; Email Id : </label>
          <input
            type="email"
            placeholder="Enter email id"
            v-model="input.email"
          />
          <p></p>
          <label for="password">&nbsp;&nbsp; Password : </label>
          <input
            type="Password"
            placeholder="Enter password"
            v-model="input.password"
          />
        </h3>
        <p></p>
        <div class="checkbox">
          <label
            ><input type="checkbox" checked name="remember" /> Remember
            me</label
          >
          <p></p>
        </div>
        <button class="button" v-on:click="auth()">Submit &nbsp;</button>
      </fieldset>
    </form>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "Home",
  data() {
    return {
      input: {
        email: "",
        password: "",
      },
    };
  },
  methods: {
    login() {
      axios
        .get(" ")
        .then((response) => {})
        .catch((error) => {});
      this.$router.push({
        name: "Simulator",
      });
    },
    auth() {
      if (this.input.email !== "" && this.input.password !== "") {
        if (
          this.input.email === "admin@nl.abnamro.com" &&
          this.input.password === "admin000"
        ) {
          alert("login successful");
          this.login();
        } else {
          alert("The email or password is incorrect");
        }
      } else {
        if (this.input.email === "" || this.input.password === "") {
          alert("Email and password must be present");
        }
      }
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  display: block;
  font-size: 1em;
  margin-top: 0.67em;
  margin-bottom: 0.67em;
  margin-left: 0em;
  margin-right: 0em;
  font-weight: bold;
}
.feild {
  height: 150px;
  width: 500px;
  margin-left: 400px;
  margin-top: 100px;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.button {
  background-color: yellow;
  display: inline-block;
  border-radius: 12px;
  margin: 10px;
  box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24),
    0 17px 50px 0 rgba(0, 0, 0, 0.19);
}
</style>
