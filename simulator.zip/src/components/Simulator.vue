<template>
  <div>
    <h3>SIMULATOR</h3>
  </div>
</template>
<script>
export default {
  name: "Simulator",
};
</script>