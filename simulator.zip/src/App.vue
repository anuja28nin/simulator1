<template>
  <div id="app">
    <img alt="ABN AMRO logo" src="./assets/logo.png" width="15%" align="left" />
    <svg width="1370" height="50">
      <rect width="2000" height="50" style="fill: rgb(0, 133, 122)" />
    </svg>
    <ul>
      <li><router-link to="/home">Login</router-link></li>
    </ul>
    <router-view></router-view>
    <footer class="footer">
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/index.html"
          target="_blank"
          rel="noopener"
          >About ABN AMRO
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/secure-banking/index.html"
          target="_blank"
          rel="noopener"
          >Security
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/index.html"
          target="_blank"
          rel="noopener"
          >Accessablity
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/privacy/index.html"
          target="_blank"
          rel="noopener"
          >Privacy and cookies
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/disclaimer.html"
          target="_blank"
          rel="noopener"
          >Disclaimer</a
        >
      </li>
      <p class="abcd">©2021 ABN AMRO Bank N.V</p>
    </footer>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
};
</script>

<style>
li {
  list-style: none;
  display: inline-block;
  margin: 0 10px;
}
ul {
  text-align: right;
}

#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 20px;
}
body {
  background-color: whitesmoke;
}
img {
  margin-top: -20px;
  margin-left: -10px;
}
svg {
  margin-left: -15px;
}
a {
  color: rgb(0, 133, 122);
}
.footer {
  padding: 5px;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #b6d1cd;
  color: black;
  text-align: center;
}
.abcd {
  font-size: 10px;
  text-align: right;
}
</style>
