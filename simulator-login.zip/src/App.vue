<template>
  <div id="app">
    <img alt="ABN AMRO logo" src="./assets/logo.png" width="15%" align="left" />
    <svg width="1370" height="50">
      <rect width="2000" height="50" style="fill: rgb(0, 133, 122)" />
    </svg>
    <login msg="Welcome to the EFM Simulator" />
    <simulator msg="Welcome to the Simulator" />
  </div>
</template>

<script>
import login from "./components/login";
import simulator from "./components/simulator";

export default {
  name: "App",
  components: {
    login,
  },
  name1: "App",
  components1: {
    simulator,
  },
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 20px;
}
body {
  background-color: whitesmoke;
}
img {
  margin-top: -20px;
  margin-left: -10px;
}
svg {
  margin-left: -15px;
}
</style>
