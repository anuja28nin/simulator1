import Vue from "vue";
import Router from "vue-router";
import Login from "@/components/login";
import Simulator from "@/components/simulator";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: "/",
      redirect: {
        name: "Login"
      }
    },
    {
      path: "/login",
      name: "Login",
      component: Login
    },
    {
      path: "/simulator",
      name: "Simulator",
      component: Simulator
    }
  ]
});
