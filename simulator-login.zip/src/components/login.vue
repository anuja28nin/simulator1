<template>
  <div class="hello">
    <h1>Welcome to the EFM Simulator</h1>

    <div class="container">
      <form action=" ">
        <fieldset class="feild">
          <legend>Login:</legend>
          <div class="form-group">
            <h3>
              <label for="email">&nbsp;&nbsp; Email Id : </label>
              <input
                type="email"
                class="form-control"
                id="email"
                placeholder="Enter email id"
                v-model="input.email"
                name="email"
              />
            </h3>
          </div>
          <div class="form-group">
            <h3>
              <label for="pwd">Password : </label>
              <input
                type="password"
                class="form-control"
                id="pwd"
                placeholder="Enter password"
                v-model="input.password"
                name="pwd"
              />
            </h3>
          </div>
          <p></p>
          <div class="checkbox">
            <label
              ><input type="checkbox" checked name="remember" /> Remember
              me</label
            >
          </div>
          <p>
            <button type="submit" v-on:click="login()" class="button">
              Submit
            </button>
          </p>
        </fieldset>
      </form>
    </div>

    <footer class="footer">
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/index.html"
          target="_blank"
          rel="noopener"
          >About ABN AMRO
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/secure-banking/index.html"
          target="_blank"
          rel="noopener"
          >Security
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/index.html"
          target="_blank"
          rel="noopener"
          >Accessablity
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/privacy/index.html"
          target="_blank"
          rel="noopener"
          >Privacy and cookies
        </a>
      </li>
      <li>
        <a
          href="https://www.abnamro.nl/en/personal/overabnamro/disclaimer.html"
          target="_blank"
          rel="noopener"
          >Disclaimer</a
        >
      </li>
      <p class="abcd">©2021 ABN AMRO Bank N.V</p>
    </footer>
  </div>
</template>

<script>
export default {
  name: "Login",
  data() {
    return {
      input: {
        email: "",
        password: "",
      },
    };
  },
  methods: {
    login() {
      if (this.input.email !== "" && this.input.password !== "") {
        if (
          this.input.email === "admin@nl.abnamro.com" &&
          this.input.password === "admin000"
        ) {
          alert("login successful");
        } else {
          alert("The email or password is incorrect");
        }
      } else {
        if (this.input.email === "" || this.input.password === "") {
          alert("Email and password must be present");
        }
      }
    },
  },
};
</script>>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  display: block;
  font-size: 1em;
  margin-top: 0.67em;
  margin-bottom: 0.67em;
  margin-left: 0em;
  margin-right: 0em;
  font-weight: bold;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: rgb(0, 133, 122);
}
.footer {
  padding: 5px;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #b6d1cd;
  color: black;
  text-align: center;
}
.feild {
  height: 150px;
  width: 500px;
  margin-left: 400px;
  margin-top: 100px;
}
.abcd {
  font-size: 10px;
  text-align: right;
}
.button {
  background-color: yellow;
}
</style>
